<?php
//include required phpmailer files
require_once ('../PHPMailer/PHPMailer.php');
require_once ('../PHPMailer/Exception.php');
require_once ('../PHPMailer/SMTP.php');
//define name spaces
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

class CodeVerify {

	private $_link = null;
	
	function __construct(){
		$this->_link = (new Database())->connect();
	}
	function SetCode (){
		$token = 'qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNM0123456789!$/()*';
		$token = str_shuffle($token);
		$token = substr($token, 0, 10);
		return $token;
	}
	function SendCodeTo ($email,$token,$fname,$lname,$subject,$url){
		$mail = new PHPMailer();
		//set mailer to use stmp
		$mail->isSMTP();
		//define smtp host name
		$mail->Host = "smtp.gmail.com";
		//enable smtp authentication
		$mail->SMTPAuth = "true";
		//set type of encryption tls or ssl
		$mail->SMTPSecure = "tls";
		//set port to connect smtp
		$mail->Port = "587";
		//set gmail username
		$mail->Username = "thoverdz@gmail.com";
		//set gmail password
		$mail->Password = "THoDz_<php+213?>";
		//information about the email we will send
        $mail->setFrom('azomaki07@gmail.com');
        $mail->addAddress($email, $fname . " " . $lname);
        $mail->isHTML(true);
        $destination = 'localhost/THODZ/' . $url . '?email=' . $email . '&token=' . $token;
        $mail->Subject = 'THODZ|' . $subject;
        $mail->Body = "
            <h1><b>THODZ<b></h1><h3>Please click on the link below to verify your email:<br><br>
            
            <b><a href=$destination>Click Here</a></b></h3>
        ";
		if(!$mail->send()) {
		    echo 'Message could not be sent.';
		    echo 'Mailer Error: ' . $mail->ErrorInfo;
		}
	}
}