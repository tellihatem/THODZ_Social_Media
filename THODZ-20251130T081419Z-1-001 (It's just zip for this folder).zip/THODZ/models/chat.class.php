<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!(isset($_SESSION['IS_LOGGED']) && $_SESSION['IS_LOGGED'] == true && isset($_SESSION['uid']))){
    header("location: ../login.php");
    die();
}
require_once('database.class.php');
require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));

class Chat {
	private $_link = null;
		
	function __construct(){
		$this->_link = (new Database())->connect();
	}

	public function getAllUsers($id){
		//get the recent users i have chat with
		$user = new User();
		$users;
		$stmt = $this->_link->prepare('SELECT * FROM messages WHERE incoming_msg_id = ? || outgoing_msg_id = ? ORDER BY mid desc');
		$stmt->bindParam(1,$id,PDO::PARAM_INT);
		$stmt->bindParam(2,$id,PDO::PARAM_INT);
		$stmt->execute();
		if ($stmt->rowCount() > 0){
			$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
			//we must loop in the result and get all data of those users that is not the current user itself($id=Session)
			foreach($result as $lastuser_chatwith){
				if ($lastuser_chatwith['outgoing_msg_id'] == $id){
					$lastuser = $user->getSingleUser($lastuser_chatwith['incoming_msg_id']);
					if (isset($users) && is_array($users)){
						if (!in_array($lastuser,$users)){
							$users[] = $lastuser;
						}
					}else{
						$users[] = $lastuser;
					}
				}else{
					$lastuser = $user->getSingleUser($lastuser_chatwith['outgoing_msg_id']);
					if (isset($users) && is_array($users)){
						if (!in_array($lastuser,$users)){
							$users[] = $lastuser;
						}
					}else{
						$users[] = $lastuser;
					}
				}
			}
		}
		//get the users i follow
		$following = $user->getFollowing($id,'user');
		if (is_array($following)){
			foreach ($following as $user_i_follow){
				$data_following = $user->getSingleUser($user_i_follow);
				if (isset($users) && is_array($users)){
					if (!in_array($data_following,$users)){
							$users[] = $data_following;
					}
				}else{
					$users[] = $data_following;
				}
			}
		}
		//get the others users
		$others = $user->getAllUsers($id);
		if (is_array($others)){
			if (isset($users) && is_array($users)){
				foreach($others as $other){
					if (!in_array($other,$users)){
						$users[] = $other;
					}
				}
			}else{
				$users = $others;
			}
		}
		//order the list by the priority in the right way
		return $users;
	}

	public function getSearchUsers($id,$value){
		$user = new User();
		$search_users = $user->getSearchUsers($id,$value);
		return $search_users;
	}

	public function insertMessage($message,$user_id){
		$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : 0;
		if (is_numeric($user_id) && $uid > 0) {
			if (!empty($message)){
				$stmt = $this->_link->prepare('INSERT INTO messages (incoming_msg_id,outgoing_msg_id,msg) VALUES (?,?,?)');
				$stmt->bindParam(1,$user_id,PDO::PARAM_INT);
				$stmt->bindParam(2,$uid,PDO::PARAM_INT);
				$stmt->bindParam(3,$message,PDO::PARAM_STR);
				$stmt->execute();
			}
		}
		return false;
	}

	public function getMessages($uid,$chat_with){
		if (is_numeric($chat_with) && is_numeric($uid)) {
			$stmt = $this->_link->prepare('SELECT * FROM messages WHERE (incoming_msg_id = ? AND outgoing_msg_id = ?) OR (incoming_msg_id = ? AND outgoing_msg_id = ?)');
			$stmt->bindParam(1,$uid,PDO::PARAM_INT);
			$stmt->bindParam(2,$chat_with,PDO::PARAM_INT);
			$stmt->bindParam(3,$chat_with,PDO::PARAM_INT);
			$stmt->bindParam(4,$uid,PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount() > 0){
				return $stmt->fetchAll(PDO::FETCH_ASSOC);
			}
		}
		return false;
	}

	public function getLastMessage($user_id,$uid){
		if (is_numeric($user_id) && is_numeric($uid)) {
			$stmt = $this->_link->prepare('SELECT * FROM messages WHERE (incoming_msg_id = ? AND outgoing_msg_id = ?) OR (incoming_msg_id = ? AND outgoing_msg_id = ?) ORDER BY mid desc limit 1');
			$stmt->bindParam(1,$uid,PDO::PARAM_INT);
			$stmt->bindParam(2,$user_id,PDO::PARAM_INT);
			$stmt->bindParam(3,$user_id,PDO::PARAM_INT);
			$stmt->bindParam(4,$uid,PDO::PARAM_INT);
			$stmt->execute();
			if ($stmt->rowCount() > 0){
				$result = $stmt->fetchAll(PDO::FETCH_ASSOC);
				$you = "";
				$count = 28;
				if ($result[0]['outgoing_msg_id'] == $uid){
					$you = "You: ";
					$count = 23;
				}
				$output = html_entity_decode($result[0]['msg']);
				if (strlen($output) > $count){
					$output = $you . substr($output,0,$count);
				}
				$output .= "...";
				return $output;
			}
		}
		return "No message available";
	}
}