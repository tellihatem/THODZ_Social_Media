<?php
require_once('database.class.php');

class Login{
	
	private $_link = null;
	
	function __construct(){
		$this->_link = (new Database())->connect();
	}

	protected function isUser($email){
		$stmt = $this->_link->prepare('SELECT email from users WHERE email = ?;');
		$stmt->bindParam(1, $email, PDO::PARAM_STR);
		if (!$stmt->execute()){
			$stmt = null;
			header("location: ../index.php?error=stmtfailed");
			die();
		}
		if ($stmt->rowCount() > 0){
			return true;
		}
		$stmt = null;
		return false;
	}
	protected function Login ($email , $password) {
		$stmt = $this->_link->prepare('SELECT password from users WHERE email = ?;');
		$stmt->bindParam(1,$email,PDO::PARAM_STR);
		if (!$stmt->execute()){
			$stmt = null;
			header("location: ../index.php?error=stmtfailed");
			exit();
		}
		
		$passHashed = $stmt->fetchAll(PDO::FETCH_ASSOC);

		if ($password != $passHashed[0]["password"]){
			$stmt = null;
			return false;
			exit();
		}
		if ($password == $passHashed[0]["password"]){
			$stmt = $this->_link->prepare('SELECT * from users WHERE email = ? AND password = ?;');
			$stmt->bindParam(1,$email,PDO::PARAM_STR);
			$stmt->bindParam(2,$password,PDO::PARAM_STR);
			if (!$stmt->execute()){
				$stmt = null;
				header("location: ../index.php?error=stmtfailed");
				exit();
			}

			$user = $stmt->fetchAll(PDO::FETCH_ASSOC);
			if ($user[0]["isEmailConfirmed"]){
				session_start();
				$_SESSION['IS_LOGGED'] = true;
				$_SESSION["uid"] = $user[0]["uid"];
				$online = "online";
				$stmt = $this->_link->prepare('UPDATE users SET status = ? WHERE uid = ? limit 1');
				$stmt->bindParam(1,$online,PDO::PARAM_STR);
				$stmt->bindParam(2,$_SESSION['uid'],PDO::PARAM_INT);
				$stmt->execute();
				$stmt = null;
				header("location: ../home.php");
			}else{
				return "Error: Verify your account please we send you confirmation link in your email";
			}
		}
		$stmt = null;
	}

	public function checkLogin($id){
		
	}
}