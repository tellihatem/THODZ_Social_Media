<?php 

class Database{

	const DB_SERVER = 'localhost';
	const DB_USER = "root";
	const DB_PASS = "";
	const DB_NAME = "THODZ";

	function connect(){
		$conn = null;
		try {
		    $conn = new PDO('mysql:'.self::DB_SERVER.'=localhost;dbname='.self::DB_NAME, self::DB_USER, self::DB_PASS);
		    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch (PDOException $e) {
		    print "Error!: " . $e->getMessage() . "<br/>";
		    die();
		}
		return $conn;
	}
}