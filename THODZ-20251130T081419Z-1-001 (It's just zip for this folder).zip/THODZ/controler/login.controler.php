<?php 

require_once('../models/login.class.php');

class Logincontr extends Login{

	const salt = 'THODZ';
	
	private function checksum($password){
		return self::salt.md5($password);
	}

	private function isEmail($email){
		// Remove all illegal characters from email
		$email = filter_var($email, FILTER_SANITIZE_EMAIL);
		if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		    return true;
		} else {
		    return false;
		}
	}

	private function isBetween($password, $min, $max){
		if (strlen($password) < $min || strlen($password) > $max)
			return false;
		else
			return true;
	}
	// it not secure against CSRF attack
	public function isValidLogin($email, $password){
		if (empty($email) || empty($password)){
			return 'Error: there is empty feild required';
		}
		elseif(!$this->isEmail($email)){
			return 'Error: your email is not valid';
			exit();
		}
		elseif(!$this->isBetween(html_entity_decode($password), 4, 16)){
			return 'Error: password length must be between 4 and 16 charaters';
			exit();
		}
		elseif(!$this->isUser($email)){
			return 'Error: this user does not exist: '.$email; // XSS
			exit();
		}
		else{
			$password = $this->checksum($password);
			$result = $this->login($email, $password);
			if ($result == false){
				return 'Error: password or email incorrect';
			}else{
				return $result;
			}
		}
	}
}