<?php 
$action = !isset($_GET['action']) ? '' : htmlentities(trim($_GET['action']));
if ($action == 'addpost'){
	if(isset($_POST['pid'])){
		$postid = htmlspecialchars($_POST['pid']);
		require_once(realpath('D:\xamp\htdocs\THODZ\models\post.class.php'));
		$pid = new Post();
		$POST = $pid->get_singlePost($postid,$_SESSION['uid']);
		if (is_array($POST)){
			if ($POST['owner'] == $_SESSION['uid']){
				require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));
	            $user = new User();
	            $ROW_USER = $user->getData($POST['owner']);
	            require_once(realpath('D:\xamp\htdocs\THODZ\controler\image.controler.php'));
	            $images = new Image();
	            if (isset($ROW_USER['profileimg']) && !empty($ROW_USER['profileimg'])){
	                $ROW_USER['profileimg'] = "." . $ROW_USER['profileimg'];
	            }
	            if (isset($POST['postimg']) && !empty($POST['postimg'])){
	                $image = "../uploads/" . $ROW_USER['uid'] . "/" . $POST['postimg'];
	            }
	            include_once('../post.php');
			}
		}
	}
}
elseif ($action == 'addcomment'){
	if(isset($_POST['pid']) && isset($_POST['cid'])){
		$postid = htmlspecialchars($_POST['pid']);
		$commentid = htmlspecialchars($_POST['cid']);
		require_once(realpath('D:\xamp\htdocs\THODZ\models\post.class.php'));
		$post = new Post();
		$COMMENT = $post->get_singleComment($postid,$commentid);
		if (is_array($COMMENT)){
			require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));
	        $user = new User();
			$comment_user = $user->getData($COMMENT['owner']);
			if (is_array($comment_user)){
				require_once(realpath('D:\xamp\htdocs\THODZ\controler\image.controler.php'));
	            $images = new Image();
	            if (isset($comment_user['profileimg']) && !empty($comment_user['profileimg'])){
	                $comment_user['profileimg'] = "." . $comment_user['profileimg'];
	            }
	            if (isset($COMMENT['postimg']) && !empty($COMMENT['postimg'])){
	                $comment_image = "../uploads/" . $comment_user['uid'] . "/" . $COMMENT['postimg'];
	            }
		        include('../comment.php');
	    	}
		}   
	}
}
elseif ($action == 'getlikes'){
	if(isset($_POST['pid'])){
		$postid = intval($_POST['pid']);
		require_once(realpath('D:\xamp\htdocs\THODZ\controler\image.controler.php'));
		require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));
		$user = new User();
		$images = new Image();
		$likes = $user->getFollowers($postid,'post');
		if (is_array($likes)){
			foreach($likes as $like){
				$user_liked = $user->getData($like['uid']);
				if (isset($user_liked['profileimg']) && !empty($user_liked['profileimg'])){
					$profile_image = "." . $user_liked['profileimg']; 
	                $profile_image  = $images->get_thumb_profile($profile_image);
	            }else{
	                $profile_image = "../images/user_female.jpg";
	                if ($user_liked['gender'] == 'male'){
	                    $profile_image = "../images/user_male.jpg";
	                }
	            }
	            $profile_image = "." . substr($profile_image,strpos($profile_image,"/"),strlen($profile_image));
	            $full_name = html_entity_decode($user_liked['fname']) ." ". html_entity_decode($user_liked['lname']);
				echo"<div class='person_liked'><div class='liked_user_info'><a href='./profile.php?uid=".$user_liked['uid']."'><img src='".$profile_image."'></a><a href='./profile.php?uid=".$user_liked['uid']."'><h3>".$full_name."</h3></a></div><i class='far fa-thumbs-up'></i></div>";
			}
		}else{
			echo "<span class='person_liked' style = 'color:black;font-weight=bold;font-size=20px;'>No one has liked this post</span>";
		}
	}
}
elseif ($action == 'chatusers'){
	require_once(realpath('D:\xamp\htdocs\THODZ\controler\image.controler.php'));
	require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));
	require_once(realpath('D:\xamp\htdocs\THODZ\models\chat.class.php'));
	$chat = new Chat();
	$user = new User();
	$images = new Image();
	$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : 0;
	$users = $chat->getAllUsers($uid);
	if (is_array($users)){
		foreach($users as $user_chat){
			if ($user_chat['uid'] != $uid){
				$lastMessage = $chat->getLastMessage($user_chat['uid'],$uid);
				if (isset($user_chat['profileimg']) && !empty($user_chat['profileimg'])){
	          		$user_chat_profile_img = "../uploads/" . $user_chat['uid'] . "/" . $user_chat['profileimg'];
		      	}else{
		          	$user_chat_profile_img = "../images/user_female.jpg";
		          	if ($user_chat['gender'] == 'male'){
		              $user_chat_profile_img = "../images/user_male.jpg";
		          	}
		      	}
		      	$user_chat_profile_img = $images->get_thumb_profile($user_chat_profile_img);
      	  		$user_chat_profile_img = "." . substr($user_chat_profile_img,strpos($user_chat_profile_img,"/"),strlen($user_chat_profile_img));
				($user_chat['status'] == "offline") ? $offline = "offline" : $offline = "";
				echo "<a href='chat.php?uid=".$user_chat['uid']."'>
	          <div class='content'>
	            <img src='".$user_chat_profile_img."' alt=''>
	            <div class='details'>
	              <span>".html_entity_decode($user_chat['fname']) . ' ' .html_entity_decode($user_chat['lname'])."</span>
	              <p>".$lastMessage."</p>
	            </div>
	          </div>
	          <div class='status-dot ".$offline."'><i class='fas fa-circle'></i></div>
	        </a>";
				//get last message send
			}
		}
	}else{
			echo "No user to chat for now";
		}
}
elseif ($action == 'chatsearch'){
	if (isset($_POST['searchfor'])){
		require_once(realpath('D:\xamp\htdocs\THODZ\controler\image.controler.php'));
		require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));
		require_once(realpath('D:\xamp\htdocs\THODZ\models\chat.class.php'));
		$chat = new Chat();
		$user = new User();
		$images = new Image();
		$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : 0;
		$value = !isset($_POST['searchfor']) ? '' : strtolower(htmlentities(trim($_POST['searchfor'])));
		$users = $chat->getSearchUsers($uid,$value);
		if (is_array($users)){
			foreach($users as $user_chat){
				//get info
				if (isset($user_chat['profileimg']) && !empty($user_chat['profileimg'])){
	          		$user_chat_profile_img = "../uploads/" . $user_chat['uid'] . "/" . $user_chat['profileimg'];
		      	}else{
		          	$user_chat_profile_img = "../images/user_female.jpg";
		          	if ($user_chat['gender'] == 'male'){
		              $user_chat_profile_img = "../images/user_male.jpg";
		          	}
		      }
	      	$user_chat_profile_img = $images->get_thumb_profile($user_chat_profile_img);
      	  	$user_chat_profile_img = "." . substr($user_chat_profile_img,strpos($user_chat_profile_img,"/"),strlen($user_chat_profile_img));
				$lastMessage = $chat->getLastMessage($user_chat['uid'],$uid);
				($user_chat['status'] == "offline") ? $offline = "offline" : $offline = "";
				echo "<a href='chat.php?uid=".$user_chat['uid']."'>
	          <div class='content'>
	            <img src='".$user_chat_profile_img."' alt=''>
	            <div class='details'>
	              <span>".html_entity_decode($user_chat['fname']) . ' ' .html_entity_decode($user_chat['lname'])."</span>
	              <p>".$lastMessage."</p>
	            </div>
	          </div>
	          <div class='status-dot ".$offline."'><i class='fas fa-circle'></i></div>
	        </a>";
				//get last message send
			}
		}else{
			echo "No user found related to your search term";
		}
	}else{
		echo "No user found related to your search term";
	}
}
elseif ($action == 'chatmessages'){
	if (isset($_POST['chatwith'])){
		require_once(realpath('D:\xamp\htdocs\THODZ\controler\image.controler.php'));
		require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));
		require_once(realpath('D:\xamp\htdocs\THODZ\models\chat.class.php'));
		$chat = new Chat();
		$user = new User();
		$images = new Image();
		$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : 0;
		$chat_with = !isset($_POST['chatwith']) ? '' : htmlentities(trim($_POST['chatwith']));
		$chat_user = $user->getData($chat_with);
		if (is_array($chat_user)){
			$messages = $chat->getMessages($uid,$chat_with);
			if (is_array($messages)){
				foreach($messages as $message){
					if ($message['outgoing_msg_id'] == $uid){ //that mean he is the sender
						echo "<div class='chat outgoing'>
						          <div class='details'>
						              <p>".$message['msg']."</p>
						          </div>
						       </div>";
					}else{//he is the receiver
						echo "<div class='chat incoming'>
						          <img src='".$chat_user['profileimg']."' alt=''>
						          <div class='details'>
						              <p>".$message['msg']."</p>
						          </div>
						       </div>";
					}
				}
			}else{
				echo "<span style='margin-left: 25%;'>No message available</span>";
			}
		}
	}
}
elseif ($action == 'thodzsearch'){
	if (isset($_POST['searchfor'])){
		require_once(realpath('D:\xamp\htdocs\THODZ\controler\image.controler.php'));
		require_once(realpath('D:\xamp\htdocs\THODZ\models\user.class.php'));
		require_once(realpath('D:\xamp\htdocs\THODZ\models\chat.class.php'));
		$user = new User();
		$images = new Image();
		$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : 0;
		$value = !isset($_POST['searchfor']) ? '' : strtolower(htmlentities(trim($_POST['searchfor'])));
		$users = $user->getSearchUsers($uid,$value);
		if (is_array($users)){
			foreach($users as $usersearch){
				if (isset($usersearch['profileimg']) && !empty($usersearch['profileimg'])){
		          	$usersearch_profile_img = "../uploads/" . $usersearch['uid'] . "/" . $usersearch['profileimg'];
			    }else{
		          	$usersearch_profile_img = "../images/user_female.jpg";
		          	if ($usersearch['gender'] == 'male'){
		              $usersearch_profile_img = "../images/user_male.jpg";
          			}
      			}
      			$usersearch_profile_img = $images->get_thumb_profile($usersearch_profile_img);
      			$usersearch_profile_img = "." . substr($usersearch_profile_img,strpos($usersearch_profile_img,"/"),strlen($usersearch_profile_img));
      			echo "<div class='person_search'>
                        <div class='liked_user_info'>
                            <a href='./profile.php?uid=".$usersearch['uid']."'><img src='".$usersearch_profile_img."'></a>
                            <a href='./profile.php?uid=".$usersearch['uid']."'><h3>".html_entity_decode($usersearch['fname']) . ' ' . html_entity_decode($usersearch['lname'])."</h3></a>
                            
                        </div>
                       <i class='fa fa-user-plus' style='color: black;'></i>
                    </div>";
	  		}
		}else{
			echo "<span class='person_liked' style = 'color:black;font-weight=bold;font-size=20px;'>No user found related to your search term</span>";
		}
	}else{
		echo "<span class='person_liked' style = 'color:black;font-weight=bold;font-size=20px;'>No user found related to your search term</span>";
	}
}