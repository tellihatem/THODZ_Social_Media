<?php 
header("Content-type: application/json; charset=utf-8");
$action = !isset($_GET['action']) ? '' : htmlentities(trim($_GET['action']));
$json = [];
if(empty($action)){
	$json = [
		'error' => true,
		'message' => 'You can not access this file directly from your browser'
	];
}
else{
	$result = null;
	if($action == 'signup'){
		require_once('../controler/signup.controler.php');
		$signup = new Signupcontr();
		$fname = !isset($_POST['fname']) ? '' : htmlentities(trim($_POST['fname']));
		$lname = !isset($_POST['lname']) ? '' : htmlentities(trim($_POST['lname']));
		$email = !isset($_POST['email']) ? '' : htmlentities(trim($_POST['email']));
		$password = !isset($_POST['password']) ? '' : htmlentities(trim($_POST['password']));
		//$img = !isset($_FILES['image']) ? '' : $_FILES['image'];
		$gender = filter_input(INPUT_POST, 'gender', FILTER_SANITIZE_STRING);
		//$result = $signup->isValidSignup($fname, $lname, $email, $password, $img);
		$result = $signup->isValidSignup($fname, $lname, $email, $password, $gender);
		if($result !== NULL){
			$json = [
				'error' => true,
				'message' => $result
			];
		}else{
			$json = [
				'error' => false,
				'message' => 'Your registration has been successfully completed. You have just been sent an email containing membership activation link.'
			];
		}
	}
	elseif($action == 'login'){
		require_once('../controler/login.controler.php');
		$login = new Logincontr();
		$email = !isset($_POST['email']) ? '' : htmlentities(trim($_POST['email']));
		$password = !isset($_POST['password']) ? '' : htmlentities(trim($_POST['password']));
		
		$result = $login->isValidLogin($email , $password);
		
		if($result !== true){
			$json = [
				'error' => true,
				'message' => $result
			];
		}
	}
	elseif($action == 'forget'){
		require_once('../models/forget.class.php');
		$forget = new Forget();
		$email = !isset($_POST['email_forgot']) ? '' : htmlentities(trim($_POST['email_forgot']));
		$result = $forget->forget($email);
		if ($result === true){
			$json = [
				'error' => false,
				'message' => 'Operation Success. Check your email please'
			];
		}else{
			$json = [
				'error' => true,
				'message' => $result
			];
		}
	}
	elseif ($action == 'newpassword') {
		require_once('../models/forget.class.php');
		$forget = new Forget();
		$email = !isset($_POST['email_forgot']) ? '' : htmlentities(trim($_POST['email_forgot']));
		$token = !isset($_POST['token_forgot']) ? '' : htmlentities(trim($_POST['token_forgot']));
		$password = !isset($_POST['password_forgot']) ? '' : htmlentities(trim($_POST['password_forgot']));
		$result = $forget->newPassword($email,$token,$password);
		if ($result === true){
			$json = [
				'error' => false,
				'message' => 'Operation Success.'
			];
		}else{
			$json = [
				'error' => true,
				'message' => $result
			];
		}
	}
	elseif($action == 'post'){
		require_once('../models/post.class.php');
		$post = new Post();
		$text = !isset($_POST['textarea']) ? '' : htmlentities(trim($_POST['textarea']));
		$img = !isset($_FILES['image']) ? '' : $_FILES['image'];
		$result = $post->createPost($text,$img,"post",0);
		if ($result !== false){
			$json = [
				'success' => true,
				'pid' => $result
			];
		}
	}
	elseif($action == 'profileimg'){
		require_once('../models/user.class.php');
		$user = new User();
		$img = !isset($_FILES['upload_image']) ? '' : $_FILES['upload_image'];
		$result = $user->UpdateProfileImg($img);
		if ($result !== false){
			list($pid,$img) = explode(',',$result);
			$json = [
				'updateimg' => true,
				'img' => $img,
				'pid' => $pid
			];
		}
	}
	elseif($action == 'deletepost'){
		var_dump($_POST);
		require_once('../models/post.class.php');
		$post = new Post();
		$postid = !isset($_POST['postid']) ? '' : intval($_POST['postid']);
		var_dump($postid);
		$result = $post->delete_single_post($postid);
		if ($result === true){
			$json = [
				'success' => true,
				'pid' => $postid,
			];
		}elseif($result !== false){
			list($comment_counter,$postid) = explode(',',$result);
			$json = [
				'success' => true,
				'pid' => $postid,
				'comment_counter' => $comment_counter
			];
		}
	}
	elseif($action == 'like'){
		require_once('../models/post.class.php');
		$post = new Post();
		$type = !isset($_POST['type']) ? '' : htmlentities(trim($_POST['type']));
		$pid = !isset($_POST['pid']) ? '' : intval($_POST['pid']);
		$uid = !isset($_POST['uid']) ? '' : intval($_POST['uid']);
		$result = $post->like_post($type,$pid,$uid);
		if ($result !== false){
			$json = [
				'post_count' => true,
				'counter' => $result
			];
		}
	}
	elseif($action == 'addcomment'){
		require_once('../models/post.class.php');
		$post = new Post();
		$text = !isset($_POST['commentText']) ? '' : htmlentities(trim($_POST['commentText']));
		$postid = !isset($_POST['postid']) ? '' : htmlentities(trim($_POST['postid']));
		$img = !isset($_FILES['commentImage']) ? '' : $_FILES['commentImage'];
		$result = $post->createPost($text,$img,'comment',$postid);
		if ($result !== false){
			list($commentid,$comment_counter) = explode(',',$result);
			$json = [
				'success' => true,
				'commentid' => $commentid,
				'comment_counter' => $comment_counter,
				'postid' => $postid
			];
		}
	}
	elseif($action == 'settings'){
		$fname = !isset($_POST['fname']) ? '' : htmlentities(trim($_POST['fname']));
		$lname = !isset($_POST['lname']) ? '' : htmlentities(trim($_POST['lname']));
		$password = !isset($_POST['password']) ? '' : htmlentities(trim($_POST['password']));
		$rpassword = !isset($_POST['rpassword']) ? '' : htmlentities(trim($_POST['rpassword']));
		$email = !isset($_POST['email']) ? '' : htmlentities(trim($_POST['email']));
		$about = !isset($_POST['about']) ? '' : htmlentities(trim($_POST['about']));
		$currentPassword = !isset($_POST['currentpassword']) ? '' : htmlentities(trim($_POST['currentpassword']));
		require_once('../models/settings.class.php');
		$settings = new Settings();
		$result = $settings->UpdateProfile($fname,$lname,$password,$rpassword,$email,$about,$currentPassword);
		if ($result === true){
			$full_name = html_entity_decode($fname) . " " . html_entity_decode($lname);
			$email = html_entity_decode($email);
			//$about = html_entity_decode($about);
			$json = [
				'error' => false,
				'message' => 'Profile has been Updated successfully',
				'fullname' => $full_name,
				'email' => $email,
				'about' => $about
			];
		}else{
			$json = [
				'error' => true,
				'message' => $result
			];
		}
	}
	elseif ($action == 'editpost') {
		require_once('../models/post.class.php');
		$post = new Post();
		$text = !isset($_POST['textarea']) ? '' : htmlentities(trim($_POST['textarea']));
		$postid = !isset($_POST['postid_edit']) ? '' : htmlentities(trim($_POST['postid_edit']));
		$img = !isset($_FILES['image_buffer']) ? '' : $_FILES['image_buffer'];
		$result = $post->UpdatePost($text,$img,$postid);

		if ($result === true){
			$json = [
				'success' => true
			];
		}
	}
	elseif ($action == 'insertmessage'){
		require_once('../models/chat.class.php');
		$chat = new Chat();
		$message = !isset($_POST['message']) ? '' : htmlentities(trim($_POST['message']));
		$user_id = !isset($_POST['user_id']) ? '' : intval($_POST['user_id']);
		$result = $chat->insertMessage($message,$user_id);
		if ($result !== false){
			$json = [
				'success' => true
			];
		}
	}
}
echo(json_encode($json));
exit;