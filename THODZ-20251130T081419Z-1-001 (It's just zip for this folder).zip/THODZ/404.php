<?php

echo 'Page not found ' . 404;
